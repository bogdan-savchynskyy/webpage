#
# Prints values and bounds of one or two result HDF5-files.
#

import argparse
import numpy as np
import h5py
import matplotlib.pyplot as plt

if __name__ == '__main__':
    # command line parsing
    parser = argparse.ArgumentParser()
    parser.add_argument("file", help="hdf5 file with values and bounds")
    parser.add_argument('-c', dest='compare', help="hdf5 file with values and bounds to compare with")
    args = parser.parse_args()

    # load HDF5 file
    h5f = h5py.File(args.file,'r')

    # save datasets to numpy arrays
    # doesn't save the first 2 elements because they can be -inf or inf
    values = h5f['values'][2:]
    bounds = h5f['bounds'][2:]
    h5f.close()

    # if a second HDF5 is given load and save the datasets too
    if args.compare:
        h5f = h5py.File(args.compare,'r')
        compare_values = h5f['values'][2:]
        compare_bounds = h5f['bounds'][2:]
        h5f.close()
    else:
        compare_values = [values[0]]
        compare_bounds = [bounds[0]]

    # plot the values and bounds of the first result as green line and dahes
    line_values, = plt.plot(values, 'g-', label='algorithm values')
    line_bounds, = plt.plot(bounds, 'g--', label='algorithm bounds')
    plt.legend(handles=[line_values, line_bounds])

    # and plot the values and bounds of the second result as red line and dashes
    if args.compare:
        line_compare_values, = plt.plot(compare_values, 'r-', label='compare algorithm values')
        line_compare_bounds, = plt.plot(compare_bounds, 'r--', label='compare algorithm bounds')

        # overwrite legend
        plt.legend(handles=[line_values, line_bounds, line_compare_values, line_compare_bounds])

    # set the range of the y-axis
    minimum = bounds[0] if (bounds[0] < compare_bounds[0]) else compare_bounds[0]
    maximum = values[0] if (values[0] > compare_values[0]) else compare_values[0]
    plt.ylim([minimum, maximum])
    
    plt.show()
