import sys
import argparse
import numpy as np

import opengm

# generator of pairwise factors
def get_pair_pot(num_labels, pair_mult, is_potts):
    if is_potts:
        return opengm.pottsFunction([num_labels, num_labels], 0.0, pair_mult * np.random.rand()) 
    else:
        return pair_mult * np.random.rand(num_labels, num_labels)

# input arguments description
parser = argparse.ArgumentParser(description='Model constructor.')
parser.add_argument('-F', '--filename', action='store', type=str, dest='filename', default='my_model.h5', help="Filename to store model. Default: my_model.h5.")
parser.add_argument('-L', '--num_labels', action='store', type=int, dest='num_labels', default=2, help="Number of labels for each variable. Deafult: 2.")
parser.add_argument('-N', '--num_variables', action='store', type=int, dest='num_variables', default=10, help="Number of variables in each dimension, i.e. if num_variables = 10, then there are 10x10 variables in 2d grid. Default: 10.")
parser.add_argument('-G', '--grid_type', action='store', type=str, dest='grid_type', default='2d_grid', help="Type of grid: 1d_grid (chain) or 2d_grid. Default: 2d_grid.")
parser.add_argument('-U', '--unary_mult', action='store', type=float, dest='unary_mult', default=1.0, help='Multiplier for all unary potentials. Default: 1.0.')
parser.add_argument('-P', '--pair_mult', action='store', type=float, dest='pair_mult', default=1.0, help='Multiplier for all pair potentials. Default: 1.0.')
parser.add_argument('-T', '--pair_type', action='store', type=str, dest='pair_type', default='potts', help="Type of pair potentials: random ot potts. Default: potts.")

par = parser.parse_args()

# print arguments
print par.filename
print par.num_labels
print par.num_variables
print par.grid_type
print par.unary_mult
print par.pair_mult
print par.pair_type

# only grid or chain models can be generated
if par.grid_type == '1d_grid':
    is_chain = True
else:
    if par.grid_type == '2d_grid':
        is_chain = False
    else:
        sys.exit('Error: wrong grid type. See help.')

# pairwise factos potts or general
if par.pair_type == 'potts':
    is_potts = True
else:
    if par.pair_type == 'random':
        is_potts = False
    else:
        sys.exit('Error: wrong pair type. See help.')

filename = par.filename
num_labels = par.num_labels
num_variables = par.num_variables
unary_mult = par.unary_mult
pair_mult = par.pair_mult

total_num_variables = num_variables if is_chain else num_variables ** 2
# create graphical model 
gm = opengm.gm(np.ones(total_num_variables, dtype=opengm.label_type) * num_labels)

# initialize unary factors
for vi in xrange(total_num_variables):
    unary = unary_mult * np.random.rand(num_labels)
    gm.addFactor(gm.addFunction(unary), [vi])

# initialize pairwise factors
if is_chain:
    for vi in xrange(num_variables - 1):
        fid = gm.addFunction(get_pair_pot(num_labels, pair_mult, is_potts))
        gm.addFactor(fid, [vi, vi + 1])
else:
    for vi_y in xrange(num_variables):
        for vi_x in xrange(num_variables):

            if vi_x + 1 < num_variables:
                vi0 = vi_x + vi_y * num_variables
                vi1 = (vi_x + 1) + vi_y * num_variables
                fid = gm.addFunction(get_pair_pot(num_labels, pair_mult, is_potts))
                gm.addFactor(fid, [vi0, vi1])

            if vi_y + 1 < num_variables:
                vi0 = vi_x + vi_y * num_variables
                vi1 = vi_x + (vi_y + 1)  * num_variables
                fid = gm.addFunction(get_pair_pot(num_labels, pair_mult, is_potts))
                gm.addFactor(fid, [vi0, vi1])

# save the resulting model in HDF5 format
opengm.hdf5.saveGraphicalModel(gm, filename, 'gm')
