import sys
import numpy as np
import h5py
import opengm

if len(sys.argv) != 2:
    sys.exit("Error: wrong input arguments. You have to specify model filename.\nExample: python naive_solver.py my_model.h5")
file_name = sys.argv[1]

gm = opengm.adder.GraphicalModel()
opengm.hdf5.loadGraphicalModel(gm, file_name, 'gm')

labelings = np.zeros(gm.numberOfVariables)

for v in gm.variables():
    have_unary_factor = False
    unary = np.zeros(gm.numberOfLabels(v))
    factor_ids = gm.factorsOfVariable(v).__list__()
    for f in factor_ids:
        if len(gm[f].variableIndices.__list__()) == 1:
            if have_unary_factor:
                print >>sys.stderr, "Warning: variable %d has more than one unary factor!" % (v)
            have_unary_factor = True
            unary += np.array(gm[f])
    if have_unary_factor:
        labelings[v] = np.argmin(unary)
    else:
        sys.exit("Error: variable %d does not have unary factor" % (v))

# Comment the following 3 lines if h5py is not installed
f = h5py.File('naive_labeling.h5', 'w')
f.create_dataset(u'states', data=labelings)
f.close()

print "Energy value: %f" % gm.evaluate(labelings)

