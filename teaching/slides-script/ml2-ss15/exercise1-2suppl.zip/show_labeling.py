import argparse
import numpy as np
#from scipy.misc import imsave
import matplotlib.pyplot as plt
import h5py

parser = argparse.ArgumentParser()
parser.add_argument('-f', '--filename', action='store', type=str, dest='filename', default='opengm_result.h5', help="Filename to store model. Default: opengm_result.h5.")
parser.add_argument('-o', action='store', type=str, dest='image_file', default='labeling.png', help="Image file. Default: labeling.png")
parser.add_argument('-V', action='store', type=int, dest='vert_size', default=None, help="Vertical size of the labeling")
parser.add_argument('-H', action='store', type=int, dest='hor_size', default=None, help="Horizontal size of the labeling")
parser.add_argument('-v', action='store_true', dest='show_image', default=False, help="Show image. Default ")
parser.add_argument('-C', action='store_true', dest='is_C', default=True, help="C like order of rows and columns. Deafult: C like order")
parser.add_argument('-F', action='store_false', dest='is_C', help="Fartran like order of rows and columns.")

par = parser.parse_args()

order_char = 'C' if par.is_C else 'F'

f = h5py.File(par.filename, 'r')
labeling = np.array(f[u'states']).reshape((par.vert_size, par.hor_size), order=order_char)
#imsave(par.image_file, labeling, format='png')

plt.imshow(labeling, interpolation='nearest')
plt.axis('off')
plt.savefig(par.image_file, format='png')

if par.show_image:
    plt.show()


